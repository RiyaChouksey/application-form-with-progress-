document.addEventListener('DOMContentLoaded', function () {
    const formSteps = document.querySelectorAll('.form-step');
    const progress = document.getElementById('progress');
    const nextBtns = document.querySelectorAll('.next-btn');
    const prevBtns = document.querySelectorAll('.prev-btn');
    const form = document.getElementById('applicationForm');
    let currentStep = 0;

    nextBtns.forEach(button => {
        button.addEventListener('click', () => {
            currentStep++;
            updateFormSteps();
            updateProgressBar();
        });
    });

    prevBtns.forEach(button => {
        button.addEventListener('click', () => {
            currentStep--;
            updateFormSteps();
            updateProgressBar();
        });
    });

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Form submitted successfully!');
        form.reset();
        currentStep = 0;
        updateFormSteps();
        updateProgressBar();
    });

    function updateFormSteps() {
        formSteps.forEach((step, index) => {
            step.classList.toggle('active', index === currentStep);
        });
    }

    function updateProgressBar() {
        const progressPercent = ((currentStep) / (formSteps.length - 1)) * 100;
        progress.style.width = `${progressPercent}%`;
    }

    updateFormSteps();
    updateProgressBar();
});
